﻿using System;
using System.Collections.Generic;
using System.Text;

namespace test
{
    public class Motor
    {
        public string qtime { get; set; }
        public float ambient { get; set; }
        public float coolant { get; set; }
        public float u_d { get; set; }
        public float u_q { get; set; }
        public float motor_speed { get; set; }
        public float torque { get; set; }
        public float i_d { get; set; }
        public float i_q { get; set; }
        public float pm { get; set; }
        public float stator_yoke { get; set; }
        public float stator_tooth { get; set; }
        public float stator_winding { get; set; }
    }
}
