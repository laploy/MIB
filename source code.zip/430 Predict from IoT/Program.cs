﻿//  * LOY 2019 MIB Course
// Predict batch motor speed from CSV file

using Microsoft.Azure.EventHubs;
using Microsoft.ML;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace test
{
    class Program
    {
        private readonly static string s_eventHubsCompatibleEndpoint =
            "sb://ihsuprodsgres001dednamespace.servicebus.windows.net/";
        private readonly static string s_eventHubsCompatiblePath =
            "iothub-ehub-loyiothub1-2144308-c4bf924f3c";
        private readonly static string s_iotHubSasKey =
            "KCyf3omKkmWncXuKDWdFTjM1edMKKOnMIxBWRoWgmAw=";

        private readonly static string s_iotHubSasKeyName = "service";
        private static EventHubClient s_eventHubClient;
        private static ITransformer mlModel;
        private static string modelPath = @"E:\mib\MLModel.zip";
        private static MLContext mlContext = new MLContext(seed: 0);

        private static async Task GetD2CMessage(
            string partition, CancellationToken ct)
        {
            var eventHubReceiver = s_eventHubClient.CreateReceiver(
                "$Default",
                partition,
                EventPosition.FromEnqueuedTime(DateTime.Now));
            while (true)
            {
                if (ct.IsCancellationRequested) break;
                var events = await eventHubReceiver.ReceiveAsync(100);
                if (events == null) continue;
                foreach (EventData eventData in events)
                {
                    string s = Encoding.UTF8.GetString(eventData.Body.Array);
                    Motor m = new Motor();
                    m = JsonConvert.DeserializeObject<Motor>(s);
                    GetPrediction(m);
                }
            }
        }

        private static void GetPrediction(Motor m)
        {
            var motor = new ModelInput()
            {
                Ambient = m.ambient,
                Coolant = m.coolant,
                U_d = m.u_d,
                U_q = m.u_q,
                Motor_speed = m.motor_speed,
                Torque = m.torque,
                I_d = m.i_d,
                I_q = m.i_q,
                Pm = m.pm,
                Stator_yoke = m.stator_yoke,
                Stator_tooth = m.stator_tooth,
                Stator_winding = m.stator_winding
            };
            var predEngine = mlContext.Model.CreatePredictionEngine
                <ModelInput, ModelOutput>(mlModel);
            ModelOutput result = predEngine.Predict(motor);
            Console.WriteLine($"Actual: {result.Motor_speed}\t| Predict: {result.Score}");
        }

        private static async Task Main(string[] args)
        {
            mlModel = mlContext.Model.Load(modelPath, out var modelInputSchema);
            Console.WriteLine(
                "Read device to cloud messages. Ctrl-C to exit.\n");
            var connectionString = new EventHubsConnectionStringBuilder(
                new Uri(s_eventHubsCompatibleEndpoint),
                s_eventHubsCompatiblePath,
                s_iotHubSasKeyName,
                s_iotHubSasKey);
            s_eventHubClient = EventHubClient.CreateFromConnectionString(
                connectionString.ToString());
            var runtimeInfo =
                await s_eventHubClient.GetRuntimeInformationAsync();
            var d2cPartitions = runtimeInfo.PartitionIds;
            CancellationTokenSource cts = new CancellationTokenSource();
            Console.CancelKeyPress += (s, e) =>
            {
                e.Cancel = true;
                cts.Cancel();
                Console.WriteLine("Exiting...");
            };
            var tasks = new List<Task>();
            foreach (string partition in d2cPartitions)
            {
                tasks.Add(GetD2CMessage(partition, cts.Token));
            }
            Task.WaitAll(tasks.ToArray());
        }
    }
}
