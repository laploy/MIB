﻿

read data from array
and show line chart on WinForm 