﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace test2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void SetChartArea()
        {
            Title title1 = new Title();
            title1.Font = new Font("Calibri", 16.2F, FontStyle.Regular, 
                GraphicsUnit.Point, ((byte)(0)));
            title1.Name = "Title1";
            title1.Text = "IoT telemetry motor's speed VS Machine Learning prediction";
            this.chart1.Titles.Add(title1);

            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.Gainsboro;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.Gainsboro;
            chart1.ChartAreas[0].AxisY.Maximum = -1.2224250;
            chart1.ChartAreas[0].AxisY.Minimum = -1.2224350;

            chart1.ChartAreas[0].AxisX.Title = "Duration of the last 20 minutes";
            chart1.ChartAreas[0].AxisX.TitleAlignment = StringAlignment.Center;
            chart1.ChartAreas[0].AxisX.TextOrientation = TextOrientation.Horizontal;

            chart1.ChartAreas[0].AxisY.Title = "Motor speed unit in BMK";
            chart1.ChartAreas[0].AxisY.TitleAlignment = StringAlignment.Center;
            chart1.ChartAreas[0].AxisY.TextOrientation = TextOrientation.Rotated270;

            chart1.ChartAreas[0].Area3DStyle.Enable3D = true;
            chart1.ChartAreas[0].Area3DStyle.IsRightAngleAxes = false;
            chart1.ChartAreas[0].Area3DStyle.Inclination = 40;
            chart1.ChartAreas[0].Area3DStyle.Rotation = 20;

            chart1.ChartAreas[0].Area3DStyle.Enable3D = true;
            chart1.ChartAreas[0].Area3DStyle.IsRightAngleAxes = false;
            chart1.ChartAreas[0].Area3DStyle.Inclination = 40;
            chart1.ChartAreas[0].Area3DStyle.Rotation = 20;
        }
        private void IoTLine()
        {
            double[] yval = { -1.2224337, -1.2224289, -1.2224318, -1.222431,
                -1.222429, -1.2224288, -1.2224303, -1.2224288, -1.2224286, -1.2224274 };

            string[] xval = { "3:10", "3:11", "3:12", "3:13", "3:14",
                "3:15", "3:16", "3:17", "3:18", "3:19"};

            var speedSeries1 = new Series("IoT");
            speedSeries1.ChartType = SeriesChartType.Line;
            speedSeries1.Color = Color.Blue;
            chart1.Series.Add(speedSeries1);
            chart1.Series["IoT"].Points.DataBindXY(xval, yval);
            chart1.Series["IoT"].LegendText = "IoT telemetry";
        }
        private void MLLine()
        {
            double[] yval = { -1.2224337, -1.2224289, -1.2224318, -1.222431,
                -1.222429, -1.2224288, -1.2224313, -1.2224288, -1.2224286, -1.2224274 };

            string[] xval = { "3:10", "3:11", "3:12", "3:13", "3:14",
                "3:15", "3:16", "3:17", "3:18", "3:19"};

            var speedSeries2 = new Series("ML");
            speedSeries2.ChartType = SeriesChartType.Line;
            speedSeries2.Color = Color.Red;
            chart1.Series.Add(speedSeries2);
            chart1.Series["ML"].Points.DataBindXY(xval, yval);
            chart1.Series["ML"].LegendText = "ML Prediction";
            chart1.Series["ML"].IsValueShownAsLabel = true;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            SetChartArea();
            MLLine();
            IoTLine();
        }
    }
}
