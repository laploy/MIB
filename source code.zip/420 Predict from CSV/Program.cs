﻿//  * LOY 2019 MIB Course
// Predict batch motor speed from CSV file

using Microsoft.ML;
using System;
using System.Collections.Generic;
using System.Linq;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            // Set data set path
            string testDataPath = @"E:\mib\pmsm_temperature_data_test2.csv";
            string modelPath = @"E:\mib\MLModel.zip";

            // Create context
            MLContext mlContext = new MLContext(seed: 0);

            // Read test file
            string[] lines = System.IO.File.ReadAllLines(testDataPath);

            // Create Motor object array
            // - 2 because first line is header
            ModelInput[] myTest = new ModelInput[lines.Count() - 2];

            // Assign value to each object in array
            for (int i = 1; i < lines.Count() - 1; i++)
            {
                string[] myArray = lines[i].ToString().Split(',');

                // Make one test diamond data we want to predict
                int j = 0;
                var motor = new ModelInput()
                {
                    Ambient = float.Parse(myArray[j++]),
                    Coolant = float.Parse(myArray[j++]),
                    U_d = float.Parse(myArray[j++]),
                    U_q = float.Parse(myArray[j++]),
                    Motor_speed = float.Parse(myArray[j++]),
                    Torque = float.Parse(myArray[j++]),
                    I_d = float.Parse(myArray[j++]),
                    I_q = float.Parse(myArray[j++]),
                    Pm = float.Parse(myArray[j++]),
                    Stator_yoke = float.Parse(myArray[j++]),
                    Stator_tooth = float.Parse(myArray[j++]),
                    Stator_winding = float.Parse(myArray[j++]),
                };
                myTest[i - 1] = motor;
            }

            // Create IDataView from enumberable
            IDataView batchView = mlContext.Data.LoadFromEnumerable(myTest);

            // Load Model
            ITransformer loadedModel = mlContext.Model.Load(modelPath, out var modelInputSchema);

            // Create prediction view
            IDataView predictions = loadedModel.Transform(batchView);

            // Create enumerable prediction
            IEnumerable<ModelOutput> predictedResults = mlContext.Data.CreateEnumerable<ModelOutput>
                (predictions, reuseRowObject: false);

            // Display Results
            Console.WriteLine("==== Prediction with multiple rows from file ===");
            Console.WriteLine("=================================");
            Console.WriteLine($"Actual\t\t| Predicted");
            Console.WriteLine("----------------------------");
            foreach (ModelOutput prediction in predictedResults)
            {
                Console.WriteLine($"{prediction.Motor_speed}\t| {prediction.Score}");
            }
            Console.WriteLine("=============== End of predictions ===============");
        }
    }
}
