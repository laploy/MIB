﻿.NET Core console app
device simulator
send temperature and humidity to IoT Hub