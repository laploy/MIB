﻿/*
    MIB course loy vanich laploy@gmail.com
    Device SIM Send message to IoT Hub
*/

using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using System;
using System.Text;

namespace simulated_device
{
    class SimulatedDevice
    {
        private static DeviceClient s_deviceClient;
        private readonly static string s_connectionString = 
            "HostName=loyiothub1.azure-devices.net;DeviceId=loy-iot-device-1;SharedAccessKey=1aq5j0oop5tucSUco8GJ8SNuWCYV5P6hzrW0zc/YhuY=";

        private static async void SendDeviceToCloudMessagesAsync()
        {
            // Initial telemetry values
            double minTemperature = 20;
            double minHumidity = 60;
            Random rand = new Random();

            double currentTemperature = minTemperature + rand.NextDouble() * 15;
            double currentHumidity = minHumidity + rand.NextDouble() * 20;

            // Create JSON message
            var telemetryDataPoint = new
            {
                temperature = currentTemperature,
                humidity = currentHumidity
            };
            var messageString = JsonConvert.SerializeObject(telemetryDataPoint);
            var message = new Message(Encoding.ASCII.GetBytes(messageString));

            // Add a custom application property to the message.
            // An IoT hub can filter on these properties without access to the message body.
            message.Properties.Add("temperatureAlert", (currentTemperature > 30) ? "true" : "false");

            // Send the telemetry message
            await s_deviceClient.SendEventAsync(message);
            Console.WriteLine("{0} > Sending message: {1}", DateTime.Now, messageString);
        }
        private static void Main(string[] args)
        {
            // Connect to the IoT hub using the MQTT protocol
            s_deviceClient = DeviceClient.CreateFromConnectionString(
                s_connectionString, 
                TransportType.Mqtt);
            while (true)
            {
                Console.WriteLine("Press any key to send a message. Ctrl-C to exit.");
                Console.ReadLine();
                SendDeviceToCloudMessagesAsync();
            }
        }
    }
}



