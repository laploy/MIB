﻿using Microsoft.Azure.EventHubs;
using Microsoft.ML;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace test
{
    public partial class Form1 : Form
    {
        #region members
        private const float DIFF = 1;
        private Timer myTimer = new Timer();
        private bool ready = true;
        private List<Motor> datasetIoT = new List<Motor>();

        private readonly string s_eventHubsCompatibleEndpoint =
            "sb://ihsuprodsgres001dednamespace.servicebus.windows.net/";
        private readonly string s_eventHubsCompatiblePath =
            "iothub-ehub-loyiothub1-2144308-c4bf924f3c";
        private readonly string s_iotHubSasKey =
            "KCyf3omKkmWncXuKDWdFTjM1edMKKOnMIxBWRoWgmAw=";
        private readonly string s_iotHubSasKeyName = "service";
        private EventHubClient s_eventHubClient;
        private PartitionReceiver eventHubReceiver;

        private static ITransformer mlModel;
        private static string modelPath = @"E:\mib\MLModel.zip";
        private static MLContext mlContext = new MLContext(seed: 0);
        #endregion

        public Form1()
        {
            InitializeComponent();
        }
        private void SetChartArea()
        {
            Title title1 = new Title();
            title1.Font = new Font("Calibri", 16.2F, FontStyle.Regular,
                GraphicsUnit.Point, ((byte)(0)));
            title1.Name = "Title1";
            title1.Text = "IoT telemetry and ML prediction";
            this.chart1.Titles.Add(title1);

            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.Gainsboro;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.Gainsboro;
            chart1.ChartAreas[0].AxisY.Maximum = 2;
            chart1.ChartAreas[0].AxisY.Minimum = -2;

            chart1.ChartAreas[0].AxisX.Title = "Duration of the last 20 minutes";
            chart1.ChartAreas[0].AxisX.TitleAlignment = StringAlignment.Center;
            chart1.ChartAreas[0].AxisX.TextOrientation = TextOrientation.Horizontal;

            chart1.ChartAreas[0].AxisY.Title = "Motor speed unit in BMK";
            chart1.ChartAreas[0].AxisY.TitleAlignment = StringAlignment.Center;
            chart1.ChartAreas[0].AxisY.TextOrientation = TextOrientation.Rotated270;

            var speedSeries1 = new Series("IoT");
            speedSeries1.ChartType = SeriesChartType.Line;
            speedSeries1.Color = Color.Blue;
            chart1.Series.Add(speedSeries1);
            chart1.Series["IoT"].LegendText = "IoT telemetry";

            var speedSeries2 = new Series("ML");
            speedSeries2.ChartType = SeriesChartType.Line;
            speedSeries2.Color = Color.Red;
            chart1.Series.Add(speedSeries2);
            chart1.Series["ML"].LegendText = "ML Prediction";
        }
        private void IoTLine()
        {
            List<double> yl = new List<double>();
            List<string> xl = new List<string>();
            foreach(var v in datasetIoT)
            {
                yl.Add(v.motor_speed);
                xl.Add(v.qtime);
            }
            chart1.Series["IoT"].Points.DataBindXY(xl, yl);
        }
        private void MLLine()
        {
            List<double> yl = new List<double>();
            List<string> xl = new List<string>();
            foreach (var v in datasetIoT)
            {
                yl.Add(v.predict_speed);
                xl.Add(v.qtime);
            }
            chart1.Series["ML"].Points.DataBindXY(xl, yl);
        }
        private async Task GetD2CMessage()
        {
            var events = await eventHubReceiver.ReceiveAsync(100);
            if (events == null) { ready = true; return; }
            foreach (EventData eventData in events)
            {
                string s = Encoding.UTF8.GetString(eventData.Body.Array);
                Motor m = new Motor();
                m = JsonConvert.DeserializeObject<Motor>(s);

                m.qtime = DateTime.Now.ToString("h:mm:ss");
                var predict = GetPrediction(m);
                labelResult.Text += $"Actual: {m.motor_speed}   |   Predict: {predict.Score}\r\n";
                FindDifference(m.motor_speed, predict.Score);
                m.predict_speed = predict.Score;
                datasetIoT.Add(m);

                var bindingList = new BindingList<Motor>(datasetIoT);
                var source = new BindingSource(bindingList, null);
                dataGridView1.DataSource = source;
                ready = true;
            }
        }
        private ModelOutput GetPrediction(Motor m)
        {
            var motor = new ModelInput()
            {
                Ambient = m.ambient,
                Coolant = m.coolant,
                U_d = m.u_d,
                U_q = m.u_q,
                Motor_speed = m.motor_speed,
                Torque = m.torque,
                I_d = m.i_d,
                I_q = m.i_q,
                Pm = m.pm,
                Stator_yoke = m.stator_yoke,
                Stator_tooth = m.stator_tooth,
                Stator_winding = m.stator_winding
            };
            var predEngine = mlContext.Model.CreatePredictionEngine
                <ModelInput, ModelOutput>(mlModel);
            ModelOutput result = predEngine.Predict(motor);
            return result;
        }
        private void FindDifference(float iot, float ml)
        {
            var diff = Math.Abs(iot - ml);
            labelStatus.Text = $"Differnece = {diff} ";
            if(diff < DIFF)
            {
                labelStatus.BackColor = Color.Gainsboro;
                labelStatus.Text += " Motor speed is in normal parameters";
            }
            else
            {
                labelStatus.BackColor = Color.Orange;
                labelStatus.Text += " A L E R T !";
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            mlModel = mlContext.Model.Load(modelPath, out var modelInputSchema);
            SetChartArea();
            myTimer.Enabled = true;
            myTimer.Interval = 3000;
            myTimer.Tick += MyTimer_Tick;

            var connectionString = new EventHubsConnectionStringBuilder(
                new Uri(s_eventHubsCompatibleEndpoint),
                s_eventHubsCompatiblePath,
                s_iotHubSasKeyName,
                s_iotHubSasKey);
            s_eventHubClient = EventHubClient.CreateFromConnectionString(
                connectionString.ToString());
            eventHubReceiver = s_eventHubClient.CreateReceiver(
                "$Default",
                "0",
                EventPosition.FromEnqueuedTime(DateTime.Now));
        }
        private async void MyTimer_Tick(object sender, EventArgs e)
        {
            if(ready)
            {
                ready = false;
                await GetD2CMessage();
                IoTLine();
                MLLine();
            }
        }
    }
}
