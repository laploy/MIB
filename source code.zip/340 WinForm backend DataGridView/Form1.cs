﻿using Microsoft.Azure.EventHubs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.ComponentModel;

namespace test2
{
    public partial class Form1 : Form
    {
        private Timer myTimer = new Timer();
        private bool ready = true;
        private List<Motor> datasetIoT = new List<Motor>();

        private readonly string s_eventHubsCompatibleEndpoint =
            "sb://ihsuprodsgres001dednamespace.servicebus.windows.net/";
        private readonly string s_eventHubsCompatiblePath =
            "iothub-ehub-loyiothub1-2144308-c4bf924f3c";
        private readonly string s_iotHubSasKey =
            "KCyf3omKkmWncXuKDWdFTjM1edMKKOnMIxBWRoWgmAw=";
        private readonly string s_iotHubSasKeyName = "service";
        private EventHubClient s_eventHubClient;
        private PartitionReceiver eventHubReceiver;

        public Form1()
        {
            InitializeComponent();
        }
        private async Task GetD2CMessage()
        {
            var events = await eventHubReceiver.ReceiveAsync(100);
            if (events == null) { ready = true; return; }
            foreach (EventData eventData in events)
            {
                string s = Encoding.UTF8.GetString(eventData.Body.Array);
                label1.Text += $"{s} \r\r";
                Motor m = new Motor();
                m = JsonConvert.DeserializeObject<Motor>(s);
                m.qtime = DateTime.Now.ToString("h:mm:ss");
                datasetIoT.Add(m);
                var bindingList = new BindingList<Motor>(datasetIoT);
                var source = new BindingSource(bindingList, null);
                dataGridView1.DataSource = source;
                ready = true;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            myTimer.Enabled = true;
            myTimer.Interval = 3000;
            myTimer.Tick += MyTimer_Tick;

            var connectionString = new EventHubsConnectionStringBuilder(
                new Uri(s_eventHubsCompatibleEndpoint),
                s_eventHubsCompatiblePath,
                s_iotHubSasKeyName,
                s_iotHubSasKey);
            s_eventHubClient = EventHubClient.CreateFromConnectionString(
                connectionString.ToString());
            eventHubReceiver = s_eventHubClient.CreateReceiver(
                "$Default",
                "0",
                EventPosition.FromEnqueuedTime(DateTime.Now));
        }
        private async void MyTimer_Tick(object sender, EventArgs e)
        {
            if(ready)
            {
                ready = false;
                await GetD2CMessage();
            }
        }
    }
}
