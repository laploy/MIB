﻿

read D2C message from Azure IoT Hub
and convert from JSON to Motor object 
and put in to List
and binde List to the DataGridView