﻿

.NET Core console application
Backend app monitor D2C message from Azure IoT Hub

more in comment in Readme.cs