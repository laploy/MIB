﻿.NET Core console application
device simulator
send motor parameters to IoT Hub