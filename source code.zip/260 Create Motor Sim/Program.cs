﻿/*
    MIB course loy vanich laploy@gmail.com
    motor: a device SIM Send telemetry to IoT Hub
*/

using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using System;
using System.Text;
using System.IO;
using System.Collections.Generic;

namespace simulated_device
{
    class SimulatedDevice
    {
        private static List<string[]> dataset;
        private static int counter = 0;
        private static DeviceClient myDevice;
        private readonly static string connectionString = 
            "HostName=loyiothub1.azure-devices.net;DeviceId=loy-iot-device-1;SharedAccessKey=1aq5j0oop5tucSUco8GJ8SNuWCYV5P6hzrW0zc/YhuY=";

        private static void Main(string[] args)
        {
            ReadCSV();  // read test dataset
            // Connect to the IoT hub using the MQTT protocol
            myDevice = DeviceClient.CreateFromConnectionString(
                connectionString, 
                TransportType.Mqtt);
            while (true)
            {
                Console.WriteLine("Press any key to send a message. Ctrl-C to exit.");
                Console.ReadLine();
                SendD2C();
            }
        }
        private static void ReadCSV()
        {
            using (var reader = new StreamReader(
                @"e:\mib\pmsm_temperature_data_test2.csv"))
            {
                dataset = new List<string[]>();
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    dataset.Add(values);
                }
            }
        }
        private static Motor GetData()
        {
            if (counter++ > 100) counter = 0;   // dataset is 100 lines
            var v = dataset[counter];   // get array of one telemetry
            if (v.Length < 12) return null;  // telemerty must have 12 element
            Motor myMotor = new Motor();
            int i = 0;  // array index
            myMotor.ambient = float.Parse(v[i++]);
            myMotor.coolant = float.Parse(v[i++]);
            myMotor.u_d = float.Parse(v[i++]);
            myMotor.u_q = float.Parse(v[i++]);
            myMotor.motor_speed = float.Parse(v[i++]);
            myMotor.torque = float.Parse(v[i++]);
            myMotor.i_d = float.Parse(v[i++]);
            myMotor.i_q = float.Parse(v[i++]);
            myMotor.pm = float.Parse(v[i++]);
            myMotor.stator_yoke = float.Parse(v[i++]);
            myMotor.stator_tooth = float.Parse(v[i++]);
            myMotor.stator_winding = float.Parse(v[i++]);
            return myMotor;
        }
        private static async void SendD2C()
        {
            var motor = GetData();
            if (motor == null) return;
            var telemetry = new
            {
                ambient = motor.ambient,
                coolant = motor.coolant,
                u_d = motor.u_d,
                u_q = motor.u_q,
                motor_speed = motor.motor_speed,
                torque = motor.torque,
                i_d = motor.i_d,
                i_q = motor.i_q,
                pm = motor.pm,
                stator_yoke = motor.stator_yoke,
                stator_tooth = motor.stator_tooth,
                stator_winding = motor.stator_winding
            };
            var messageString = JsonConvert.SerializeObject(telemetry);
            var message = new Message(Encoding.ASCII.GetBytes(messageString));
            await myDevice.SendEventAsync(message); // Send the telemetry message
            Console.WriteLine("{0} > Sending message: {1}", DateTime.Now, messageString);
        }
    }
    public class Motor
    {
        public float ambient { get; set; }
        public float coolant { get; set; }
        public float u_d { get; set; }
        public float u_q { get; set; }
        public float motor_speed { get; set; }
        public float torque { get; set; }
        public float i_d { get; set; }
        public float i_q { get; set; }
        public float pm { get; set; }
        public float stator_yoke { get; set; }
        public float stator_tooth { get; set; }
        public float stator_winding { get; set; }
    }
}



