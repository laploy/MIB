﻿

read data from CSV data file
and show line chart on WinForm 