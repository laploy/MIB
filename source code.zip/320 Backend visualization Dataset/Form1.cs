﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.IO;
using System.Collections.Generic;

namespace test2
{
    public partial class Form1 : Form
    {
        private static List<string[]> datasetIoT;
        private static List<string[]> datasetML;
        private static int dataCounter = 0;

        public Form1()
        {
            InitializeComponent();
        }
        private static void ReadCSV()
        {
            using (var reader = new StreamReader(
                @"g:\temp\pmsm_temperature_data_test.csv"))
            {
                datasetIoT = new List<string[]>();
                datasetML = new List<string[]>();
                int counter = 0;

                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    if(counter++ < 40)
                        datasetIoT.Add(values);
                    else
                        datasetML.Add(values);
                    if (counter >= 80) break;
                }
            }
        }
        private void SetChartArea()
        {
            Title title1 = new Title();
            title1.Font = new Font("Calibri", 16.2F, FontStyle.Regular, 
                GraphicsUnit.Point, ((byte)(0)));
            title1.Name = "Title1";
            title1.Text = "IoT telemetry motor's speed VS Machine Learning prediction";
            this.chart1.Titles.Add(title1);

            chart1.ChartAreas[0].AxisX.Title = "Duration of the last 20 minutes";
            chart1.ChartAreas[0].AxisX.TitleAlignment = StringAlignment.Center;
            chart1.ChartAreas[0].AxisX.TextOrientation = TextOrientation.Horizontal;
            chart1.ChartAreas[0].AxisX.MajorGrid.LineColor = Color.Gainsboro;

            chart1.ChartAreas[0].AxisY.Title = "Motor speed unit in BMK";
            chart1.ChartAreas[0].AxisY.TitleAlignment = StringAlignment.Center;
            chart1.ChartAreas[0].AxisY.TextOrientation = TextOrientation.Rotated270;
            chart1.ChartAreas[0].AxisY.MajorGrid.LineColor = Color.Gainsboro;
            chart1.ChartAreas[0].AxisY.Maximum = -1.22242200;
            chart1.ChartAreas[0].AxisY.Minimum = -1.2224358;

            var speedSeries1 = new Series("IoT");
            speedSeries1.ChartType = SeriesChartType.Line;
            speedSeries1.Color = Color.Blue;
            chart1.Series.Add(speedSeries1);
            chart1.Series["IoT"].LegendText = "IoT telemetry";

            var speedSeries2 = new Series("ML");
            speedSeries2.ChartType = SeriesChartType.Line;
            speedSeries2.Color = Color.Red;
            chart1.Series.Add(speedSeries2);
            chart1.Series["ML"].LegendText = "ML Prediction";
        }
        private void IoTLine()
        {
            List<double> yl = new List<double>();
            List<string> xl = new List<string>();
            for (int i = 0; i < dataCounter; i++)
            {
                var v = datasetIoT[i+1];
                yl.Add(float.Parse(v[4]));
                xl.Add($"3:{i}");
            }
            chart1.Series["IoT"].Points.DataBindXY(xl, yl);
        }
        private void MLLine()
        {
            List<double> yl = new List<double>();
            List<string> xl = new List<string>();
            for (int i = 0; i < dataCounter; i++)
            {
                var v = datasetML[i + 1];
                yl.Add(float.Parse(v[4]));
                xl.Add($"3:{i}");
            }
            chart1.Series["ML"].Points.DataBindXY(xl, yl);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ReadCSV();
            SetChartArea();
        }
        private void buttonSend_Click(object sender, EventArgs e)
        {
            if (++dataCounter > 39) dataCounter = 0;
            MLLine();
            IoTLine();
        }
    }
}
