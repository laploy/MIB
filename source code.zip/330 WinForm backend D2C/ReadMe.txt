﻿

read D2C message from Azure IoT Hub
and show in the WinForm Label